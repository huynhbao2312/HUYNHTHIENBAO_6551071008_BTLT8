using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using ClosedXML.Excel;
using FastReport;
using FastReport.Export.Pdf;       // Namespace chuẩn cho FastReport PDF
using FastReport.Utils;            // Chứa Units (Millimeters)
using Microsoft.EntityFrameworkCore;
using BTCh9_Bai1.Models;

namespace BTCh9_Bai1
{
    public partial class Form1 : Form
    {
        private TiemTapHoaContext db;
        private int selectedMaHang = 0;

        public Form1()
        {
            InitializeComponent();

            // Khởi tạo DbContext an toàn kèm chuỗi kết nối
            var optionsBuilder = new DbContextOptionsBuilder<TiemTapHoaContext>();
            optionsBuilder.UseSqlServer("Server=BAO\\SQLEXPRESS01;Database=TiemTapHoa;Trusted_Connection=True;TrustServerCertificate=True;");
            db = new TiemTapHoaContext(optionsBuilder.Options);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            KhoiTaoDuLieuComboBox();
            LoadDanhSachHangHoa();
        }

        private void KhoiTaoDuLieuComboBox()
        {
            string[] dsLoai = { "Đồ uống", "Thực phẩm khô", "Gia vị", "Đồ gia dụng" };
            cboLoaiHang.Items.Clear();
            cboLoaiHang.Items.AddRange(dsLoai);
            cboLoaiHang.SelectedIndex = 0;

            cboLocLoaiHang.Items.Clear();
            cboLocLoaiHang.Items.Add("Tất cả loại");
            cboLocLoaiHang.Items.AddRange(dsLoai);
            cboLocLoaiHang.SelectedIndex = 0;

            string[] dsDonVi = { "Chai", "Gói", "Hộp", "Túi" };
            cboDonVi.Items.Clear();
            cboDonVi.Items.AddRange(dsDonVi);
            cboDonVi.SelectedIndex = 0;
        }

        // ====================== PHẦN B: HIỂN THỊ & CRUD ======================

        private void LoadDanhSachHangHoa(List<HangHoa> list = null)
        {
            if (list == null)
            {
                list = db.HangHoa.ToList();
            }

            dgvHangHoa.Rows.Clear();
            dgvHangHoa.Columns.Clear();

            dgvHangHoa.Columns.Add("MaHang", "Mã");
            dgvHangHoa.Columns.Add("TenHang", "Tên hàng");
            dgvHangHoa.Columns.Add("LoaiHang", "Loại hàng");
            dgvHangHoa.Columns.Add("DonVi", "Đơn vị");

            var colGia = new DataGridViewTextBoxColumn { Name = "GiaBan", HeaderText = "Giá bán" };
            colGia.DefaultCellStyle.Format = "N0";
            colGia.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvHangHoa.Columns.Add(colGia);

            var colTon = new DataGridViewTextBoxColumn { Name = "SoLuongTon", HeaderText = "Tồn" };
            colTon.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvHangHoa.Columns.Add(colTon);

            var colNgay = new DataGridViewTextBoxColumn { Name = "NgayNhap", HeaderText = "Ngày nhập" };
            colNgay.DefaultCellStyle.Format = "dd/MM/yyyy";
            dgvHangHoa.Columns.Add(colNgay);

            var colKinhDoanh = new DataGridViewCheckBoxColumn { Name = "ConKinhDoanh", HeaderText = "Kinh doanh" };
            dgvHangHoa.Columns.Add(colKinhDoanh);

            foreach (var item in list)
            {
                dgvHangHoa.Rows.Add(
                    item.MaHang,
                    item.TenHang,
                    item.LoaiHang,
                    item.DonVi,
                    item.GiaBan,
                    item.SoLuongTon,
                    item.NgayNhap,
                    item.ConKinhDoanh
                );
            }

            // Cập nhật trạng thái số lượng
            CapNhatThongBaoTrangThai($"Tìm thấy {list.Count} mặt hàng");
        }

        private void CapNhatThongBaoTrangThai(string msg)
        {
            // Kiểm tra an toàn xem form đã có lblTrangThai chưa
            var lbl = this.Controls.Find("lblTrangThai", true).FirstOrDefault() as Label;
            if (lbl != null)
            {
                lbl.Text = msg;
            }
        }

        private void dgvHangHoa_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.RowIndex >= dgvHangHoa.Rows.Count) return;

            DataGridViewRow row = dgvHangHoa.Rows[e.RowIndex];
            selectedMaHang = Convert.ToInt32(row.Cells["MaHang"].Value);

            var h = db.HangHoa.Find(selectedMaHang);
            if (h != null)
            {
                txtTenHang.Text = h.TenHang;
                cboLoaiHang.SelectedItem = h.LoaiHang;
                cboDonVi.SelectedItem = h.DonVi;
                nudGiaBan.Value = h.GiaBan ?? 0;
                nudSoLuongTon.Value = h.SoLuongTon ?? 0;
                dtpNgayNhap.Value = h.NgayNhap ?? DateTime.Now;
                chkConKinhDoanh.Checked = h.ConKinhDoanh;
            }
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtTenHang.Text))
            {
                MessageBox.Show("Tên hàng không được để trống!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (nudGiaBan.Value <= 0)
            {
                MessageBox.Show("Giá bán phải lớn hơn 0!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            HangHoa h = new HangHoa
            {
                TenHang = txtTenHang.Text.Trim(),
                LoaiHang = cboLoaiHang.SelectedItem?.ToString(),
                DonVi = cboDonVi.SelectedItem?.ToString(),
                GiaBan = nudGiaBan.Value,
                SoLuongTon = (int)nudSoLuongTon.Value,
                NgayNhap = dtpNgayNhap.Value,
                ConKinhDoanh = chkConKinhDoanh.Checked
            };

            db.HangHoa.Add(h);
            db.SaveChanges();
            MessageBox.Show("Thêm hàng hóa thành công!");
            ApDungBoLocTimKiem();
            LamMoiForm();
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            var h = db.HangHoa.Find(selectedMaHang);
            if (h == null)
            {
                MessageBox.Show("Vui lòng chọn hàng hóa cần sửa trên lưới!");
                return;
            }

            if (string.IsNullOrWhiteSpace(txtTenHang.Text))
            {
                MessageBox.Show("Tên hàng không được để trống!");
                return;
            }
            if (nudGiaBan.Value <= 0)
            {
                MessageBox.Show("Giá bán phải lớn hơn 0!");
                return;
            }

            h.TenHang = txtTenHang.Text.Trim();
            h.LoaiHang = cboLoaiHang.SelectedItem?.ToString();
            h.DonVi = cboDonVi.SelectedItem?.ToString();
            h.GiaBan = nudGiaBan.Value;
            h.SoLuongTon = (int)nudSoLuongTon.Value;
            h.NgayNhap = dtpNgayNhap.Value;
            h.ConKinhDoanh = chkConKinhDoanh.Checked;

            db.SaveChanges();
            MessageBox.Show("Cập nhật thành công!");
            ApDungBoLocTimKiem();
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            var h = db.HangHoa.Find(selectedMaHang);
            if (h == null)
            {
                MessageBox.Show("Vui lòng chọn hàng hóa cần xóa trên lưới!");
                return;
            }

            var confirm = MessageBox.Show($"Bạn có chắc chắn muốn xóa mặt hàng: {h.TenHang}?", "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (confirm == DialogResult.Yes)
            {
                db.HangHoa.Remove(h);
                db.SaveChanges();
                MessageBox.Show("Đã xóa mặt hàng!");
                ApDungBoLocTimKiem();
                LamMoiForm();
            }
        }

        private void btnLamMoi_Click(object sender, EventArgs e)
        {
            LamMoiForm();
            ApDungBoLocTimKiem();
        }

        private void LamMoiForm()
        {
            selectedMaHang = 0;
            txtTenHang.Clear();
            cboLoaiHang.SelectedIndex = 0;
            cboDonVi.SelectedIndex = 0;
            nudGiaBan.Value = 500;
            nudSoLuongTon.Value = 0;
            dtpNgayNhap.Value = DateTime.Now;
            chkConKinhDoanh.Checked = true;
        }

        // ====================== PHẦN C: TÌM KIẾM DEBOUNCE ======================

        private void txtTimKiem_TextChanged(object sender, EventArgs e)
        {
            timerSearch.Stop();
            timerSearch.Start();
        }

        private void timerSearch_Tick(object sender, EventArgs e)
        {
            timerSearch.Stop();
            ApDungBoLocTimKiem();
        }

        private void cboLocLoaiHang_SelectedIndexChanged(object sender, EventArgs e)
        {
            ApDungBoLocTimKiem();
        }

        private void chkLocConKinhDoanh_CheckedChanged(object sender, EventArgs e)
        {
            ApDungBoLocTimKiem();
        }

        private void ApDungBoLocTimKiem()
        {
            string tuKhoa = txtTimKiem.Text.Trim().ToLower();
            string loaiLoc = cboLocLoaiHang.SelectedItem?.ToString();
            bool chiKinhDoanh = chkLocConKinhDoanh.Checked;

            var q = db.HangHoa.AsQueryable();

            if (!string.IsNullOrEmpty(tuKhoa))
            {
                q = q.Where(x => x.TenHang.ToLower().Contains(tuKhoa));
            }

            if (cboLocLoaiHang.SelectedIndex > 0 && loaiLoc != "Tất cả loại")
            {
                q = q.Where(x => x.LoaiHang == loaiLoc);
            }

            if (chiKinhDoanh)
            {
                q = q.Where(x => x.ConKinhDoanh == true);
            }

            LoadDanhSachHangHoa(q.ToList());
        }

        // ====================== PHẦN D: FASTREPORT (DATATABLE) ======================

        private DataTable GetDataTableBangGia()
        {
            var ds = db.HangHoa.Where(x => x.ConKinhDoanh).ToList();

            DataTable dt = new DataTable("HangHoa");
            dt.Columns.Add("TenHang", typeof(string));
            dt.Columns.Add("DonVi", typeof(string));
            dt.Columns.Add("GiaBan", typeof(decimal));

            foreach (var item in ds)
            {
                dt.Rows.Add(item.TenHang, item.DonVi, item.GiaBan ?? 0);
            }
            return dt;
        }

        private Report TaoReportBangGia()
        {
            Report report = new Report();
            string pathFrx = Path.Combine(Application.StartupPath, "BangGia.frx");

            DataTable dt = GetDataTableBangGia();
            report.RegisterData(dt, "HangHoa");
            report.GetDataSource("HangHoa").Enabled = true;

            if (File.Exists(pathFrx))
            {
                report.Load(pathFrx);
            }
            else
            {
                TaoMauReportMacDinh(report, dt);
            }

            report.SetParameterValue("NgayIn", DateTime.Now.ToString("dd/MM/yyyy"));
            return report;
        }

        private void TaoMauReportMacDinh(Report report, DataTable dt)
        {
            ReportPage page = new ReportPage();
            report.Pages.Add(page);

            // Title
            ReportTitleBand titleBand = new ReportTitleBand { Height = Units.Millimeters * 20 };
            page.ReportTitle = titleBand;
            TextObject titleText = new TextObject
            {
                Bounds = new RectangleF(0, 0, Units.Millimeters * 190, Units.Millimeters * 10),
                Text = "BẢNG GIÁ HÀNG HÓA - TẠP HÓA NHÀ TRƯỜNG UTC2",
                HorzAlign = HorzAlign.Center,
                Font = new Font("Arial", 14, FontStyle.Bold)
            };
            titleBand.Objects.Add(titleText);

            TextObject ngayInText = new TextObject
            {
                Bounds = new RectangleF(0, Units.Millimeters * 10, Units.Millimeters * 190, Units.Millimeters * 8),
                Text = "Ngày in: [NgayIn]",
                HorzAlign = HorzAlign.Center,
                Font = new Font("Arial", 10, FontStyle.Regular)
            };
            titleBand.Objects.Add(ngayInText);

            // Page Header
            PageHeaderBand headerBand = new PageHeaderBand { Height = Units.Millimeters * 10 };
            page.PageHeader = headerBand;

            string[] headers = { "STT", "Tên hàng", "Đơn vị", "Giá bán" };
            float[] widths = { 15, 95, 30, 50 };
            float left = 0;
            for (int i = 0; i < headers.Length; i++)
            {
                TextObject h = new TextObject
                {
                    Bounds = new RectangleF(Units.Millimeters * left, 0, Units.Millimeters * widths[i], Units.Millimeters * 10),
                    Text = headers[i],
                    Font = new Font("Arial", 10, FontStyle.Bold),
                    Border = { Lines = BorderLines.All }
                };
                headerBand.Objects.Add(h);
                left += widths[i];
            }

            // Data Band
            DataBand dataBand = new DataBand { Height = Units.Millimeters * 8, DataSource = report.GetDataSource("HangHoa") };
            page.Bands.Add(dataBand);

            dataBand.Objects.Add(new TextObject
            {
                Bounds = new RectangleF(0, 0, Units.Millimeters * 15, Units.Millimeters * 8),
                Text = "[Row#]",
                Border = { Lines = BorderLines.All }
            });
            dataBand.Objects.Add(new TextObject
            {
                Bounds = new RectangleF(Units.Millimeters * 15, 0, Units.Millimeters * 95, Units.Millimeters * 8),
                Text = "[HangHoa.TenHang]",
                Border = { Lines = BorderLines.All }
            });
            dataBand.Objects.Add(new TextObject
            {
                Bounds = new RectangleF(Units.Millimeters * 110, 0, Units.Millimeters * 30, Units.Millimeters * 8),
                Text = "[HangHoa.DonVi]",
                Border = { Lines = BorderLines.All }
            });
            dataBand.Objects.Add(new TextObject
            {
                Bounds = new RectangleF(Units.Millimeters * 140, 0, Units.Millimeters * 50, Units.Millimeters * 8),
                Text = "[FormatNumber([HangHoa.GiaBan], 0)]",
                HorzAlign = HorzAlign.Right,
                Border = { Lines = BorderLines.All }
            });

            // Page Footer
            PageFooterBand footerBand = new PageFooterBand { Height = Units.Millimeters * 10 };
            page.PageFooter = footerBand;
            footerBand.Objects.Add(new TextObject
            {
                Bounds = new RectangleF(0, 0, Units.Millimeters * 190, Units.Millimeters * 10),
                Text = "Trang [Page#]/[TotalPages#]",
                HorzAlign = HorzAlign.Center
            });
        }

        private void btnXemBangGia_Click(object sender, EventArgs e)
        {
            using (Report r = TaoReportBangGia())
            {
                r.Show();
            }
        }

        private void btnXuatPdf_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog sfd = new SaveFileDialog { Filter = "PDF Files|*.pdf", FileName = "BangGia_UTC2.pdf" })
            {
                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    using (Report r = TaoReportBangGia())
                    {
                        r.Prepare();
                        PDFExport pdf = new PDFExport(); // Dùng PDFExport chuẩn
                        r.Export(pdf, sfd.FileName);
                    }

                    if (MessageBox.Show("Xuất file PDF thành công! Bạn có muốn mở file ngay không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        Process.Start(new ProcessStartInfo(sfd.FileName) { UseShellExecute = true });
                    }
                }
            }
        }

        // ====================== PHẦN E: XUẤT EXCEL (CLOSEDXML) ======================

        private void btnXuatExcelLuoi_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog sfd = new SaveFileDialog { Filter = "Excel Workbook|*.xlsx", FileName = "HangHoa_Luoi.xlsx" })
            {
                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        using (var workbook = new XLWorkbook())
                        {
                            var ws = workbook.Worksheets.Add("DanhSach");

                            for (int c = 0; c < dgvHangHoa.Columns.Count; c++)
                            {
                                ws.Cell(1, c + 1).Value = dgvHangHoa.Columns[c].HeaderText;
                                ws.Cell(1, c + 1).Style.Font.Bold = true;
                            }

                            for (int r = 0; r < dgvHangHoa.Rows.Count; r++)
                            {
                                for (int c = 0; c < dgvHangHoa.Columns.Count; c++)
                                {
                                    object val = dgvHangHoa.Rows[r].Cells[c].Value;
                                    var cell = ws.Cell(r + 2, c + 1);

                                    if (val == null) continue;

                                    if (decimal.TryParse(val.ToString(), out decimal numVal) && c == 4)
                                    {
                                        cell.Value = numVal;
                                        cell.Style.NumberFormat.Format = "#,##0";
                                    }
                                    else if (int.TryParse(val.ToString(), out int intVal) && (c == 0 || c == 5))
                                    {
                                        cell.Value = intVal;
                                    }
                                    else if (DateTime.TryParse(val.ToString(), out DateTime dtVal))
                                    {
                                        cell.Value = dtVal;
                                        cell.Style.NumberFormat.Format = "dd/MM/yyyy";
                                    }
                                    else
                                    {
                                        cell.Value = val.ToString();
                                    }
                                }
                            }

                            ws.Columns().AdjustToContents();
                            workbook.SaveAs(sfd.FileName);
                        }
                        MessageBox.Show("Xuất Excel từ lưới thành công!");
                    }
                    catch (IOException)
                    {
                        MessageBox.Show("File đang được mở bởi một ứng dụng khác! Vui lòng đóng file và thử lại.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
        }

        private void btnXuatExcelTonKho_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog sfd = new SaveFileDialog { Filter = "Excel Workbook|*.xlsx", FileName = "TonKho_UTC2.xlsx" })
            {
                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        var ds = db.HangHoa.Where(x => x.ConKinhDoanh).ToList();

                        using (var workbook = new XLWorkbook())
                        {
                            var ws = workbook.Worksheets.Add("TonKho");

                            string[] headers = { "Mã hàng", "Tên hàng", "Đơn vị", "Giá bán", "Số lượng tồn", "Giá trị tồn" };
                            for (int i = 0; i < headers.Length; i++)
                            {
                                var cell = ws.Cell(1, i + 1);
                                cell.Value = headers[i];
                                cell.Style.Font.Bold = true;
                                cell.Style.Fill.BackgroundColor = XLColor.LightGray;
                            }

                            int rowIdx = 2;
                            foreach (var h in ds)
                            {
                                ws.Cell(rowIdx, 1).Value = h.MaHang;
                                ws.Cell(rowIdx, 2).Value = h.TenHang;
                                ws.Cell(rowIdx, 3).Value = h.DonVi;

                                ws.Cell(rowIdx, 4).Value = h.GiaBan ?? 0;
                                ws.Cell(rowIdx, 4).Style.NumberFormat.Format = "#,##0";

                                ws.Cell(rowIdx, 5).Value = h.SoLuongTon ?? 0;
                                ws.Cell(rowIdx, 5).Style.NumberFormat.Format = "#,##0";

                                ws.Cell(rowIdx, 6).FormulaA1 = $"=D{rowIdx}*E{rowIdx}";
                                ws.Cell(rowIdx, 6).Style.NumberFormat.Format = "#,##0";

                                rowIdx++;
                            }

                            ws.Cell(rowIdx, 1).Value = "Tổng";
                            ws.Cell(rowIdx, 1).Style.Font.Bold = true;
                            ws.Range(rowIdx, 1, rowIdx, 5).Merge();

                            ws.Cell(rowIdx, 6).FormulaA1 = $"=SUM(F2:F{rowIdx - 1})";
                            ws.Cell(rowIdx, 6).Style.Font.Bold = true;
                            ws.Cell(rowIdx, 6).Style.NumberFormat.Format = "#,##0";

                            ws.SheetView.FreezeRows(1);
                            ws.Range(1, 1, rowIdx - 1, 6).SetAutoFilter();

                            ws.Columns().AdjustToContents();
                            workbook.SaveAs(sfd.FileName);
                        }
                        MessageBox.Show("Xuất file Excel tồn kho thành công!");
                    }
                    catch (IOException)
                    {
                        MessageBox.Show("File đang được mở bởi ứng dụng khác! Vui lòng đóng file rồi thử lại.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
        }
    }
}
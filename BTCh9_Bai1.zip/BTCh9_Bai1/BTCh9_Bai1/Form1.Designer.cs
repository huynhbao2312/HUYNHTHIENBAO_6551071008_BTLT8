﻿namespace BTCh9_Bai1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            grpThongTin = new GroupBox();
            chkConKinhDoanh = new CheckBox();
            dtpNgayNhap = new DateTimePicker();
            label6 = new Label();
            nudSoLuongTon = new NumericUpDown();
            label5 = new Label();
            nudGiaBan = new NumericUpDown();
            label4 = new Label();
            cboDonVi = new ComboBox();
            label3 = new Label();
            cboLoaiHang = new ComboBox();
            label2 = new Label();
            label1 = new Label();
            txtTenHang = new TextBox();
            grpTimKiem = new GroupBox();
            chkLocConKinhDoanh = new CheckBox();
            cboLocLoaiHang = new ComboBox();
            txtTimKiem = new TextBox();
            timerSearch = new System.Windows.Forms.Timer(components);
            dgvHangHoa = new DataGridView();
            btnThem = new Button();
            btnSua = new Button();
            btnXoa = new Button();
            btnLamMoi = new Button();
            btnXemBangGia = new Button();
            btnXuatPdf = new Button();
            btnXuatExcelLuoi = new Button();
            btnXuatExcelTonKho = new Button();
            label7 = new Label();
            grpThongTin.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)nudSoLuongTon).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nudGiaBan).BeginInit();
            grpTimKiem.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvHangHoa).BeginInit();
            SuspendLayout();
            // 
            // grpThongTin
            // 
            grpThongTin.Controls.Add(chkConKinhDoanh);
            grpThongTin.Controls.Add(dtpNgayNhap);
            grpThongTin.Controls.Add(label6);
            grpThongTin.Controls.Add(nudSoLuongTon);
            grpThongTin.Controls.Add(label5);
            grpThongTin.Controls.Add(nudGiaBan);
            grpThongTin.Controls.Add(label4);
            grpThongTin.Controls.Add(cboDonVi);
            grpThongTin.Controls.Add(label3);
            grpThongTin.Controls.Add(cboLoaiHang);
            grpThongTin.Controls.Add(label2);
            grpThongTin.Controls.Add(label1);
            grpThongTin.Controls.Add(txtTenHang);
            grpThongTin.Location = new Point(12, 12);
            grpThongTin.Name = "grpThongTin";
            grpThongTin.Size = new Size(716, 197);
            grpThongTin.TabIndex = 0;
            grpThongTin.TabStop = false;
            grpThongTin.Text = "Thông tin hàng hóa";
            // 
            // chkConKinhDoanh
            // 
            chkConKinhDoanh.AutoSize = true;
            chkConKinhDoanh.Checked = true;
            chkConKinhDoanh.CheckState = CheckState.Checked;
            chkConKinhDoanh.Location = new Point(436, 156);
            chkConKinhDoanh.Name = "chkConKinhDoanh";
            chkConKinhDoanh.Size = new Size(134, 24);
            chkConKinhDoanh.TabIndex = 12;
            chkConKinhDoanh.Text = "Còn kinh doanh";
            chkConKinhDoanh.UseVisualStyleBackColor = true;
            // 
            // dtpNgayNhap
            // 
            dtpNgayNhap.CustomFormat = "dd/MM/yyyy";
            dtpNgayNhap.Format = DateTimePickerFormat.Custom;
            dtpNgayNhap.Location = new Point(549, 113);
            dtpNgayNhap.Name = "dtpNgayNhap";
            dtpNgayNhap.Size = new Size(104, 27);
            dtpNgayNhap.TabIndex = 11;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(367, 111);
            label6.Name = "label6";
            label6.Size = new Size(81, 20);
            label6.TabIndex = 10;
            label6.Text = "Ngày nhập";
            // 
            // nudSoLuongTon
            // 
            nudSoLuongTon.Location = new Point(549, 69);
            nudSoLuongTon.Maximum = new decimal(new int[] { 100000, 0, 0, 0 });
            nudSoLuongTon.Name = "nudSoLuongTon";
            nudSoLuongTon.Size = new Size(106, 27);
            nudSoLuongTon.TabIndex = 9;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(367, 69);
            label5.Name = "label5";
            label5.Size = new Size(95, 20);
            label5.TabIndex = 8;
            label5.Text = "Số lượng tồn";
            // 
            // nudGiaBan
            // 
            nudGiaBan.Increment = new decimal(new int[] { 500, 0, 0, 0 });
            nudGiaBan.Location = new Point(105, 156);
            nudGiaBan.Maximum = new decimal(new int[] { 100000000, 0, 0, 0 });
            nudGiaBan.Name = "nudGiaBan";
            nudGiaBan.Size = new Size(226, 27);
            nudGiaBan.TabIndex = 7;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(14, 160);
            label4.Name = "label4";
            label4.Size = new Size(60, 20);
            label4.TabIndex = 6;
            label4.Text = "Giá bán";
            // 
            // cboDonVi
            // 
            cboDonVi.FormattingEnabled = true;
            cboDonVi.Location = new Point(107, 108);
            cboDonVi.Name = "cboDonVi";
            cboDonVi.Size = new Size(224, 28);
            cboDonVi.TabIndex = 5;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(14, 111);
            label3.Name = "label3";
            label3.Size = new Size(52, 20);
            label3.TabIndex = 4;
            label3.Text = "Đơn vị";
            // 
            // cboLoaiHang
            // 
            cboLoaiHang.FormattingEnabled = true;
            cboLoaiHang.Location = new Point(105, 61);
            cboLoaiHang.Name = "cboLoaiHang";
            cboLoaiHang.Size = new Size(226, 28);
            cboLoaiHang.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(10, 61);
            label2.Name = "label2";
            label2.Size = new Size(74, 20);
            label2.TabIndex = 2;
            label2.Text = "Loại hàng";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(6, 29);
            label1.Name = "label1";
            label1.Size = new Size(69, 20);
            label1.TabIndex = 1;
            label1.Text = "Tên hàng";
            // 
            // txtTenHang
            // 
            txtTenHang.Location = new Point(107, 26);
            txtTenHang.Name = "txtTenHang";
            txtTenHang.Size = new Size(548, 27);
            txtTenHang.TabIndex = 0;
            // 
            // grpTimKiem
            // 
            grpTimKiem.Controls.Add(chkLocConKinhDoanh);
            grpTimKiem.Controls.Add(cboLocLoaiHang);
            grpTimKiem.Controls.Add(txtTimKiem);
            grpTimKiem.Location = new Point(734, 12);
            grpTimKiem.Name = "grpTimKiem";
            grpTimKiem.Size = new Size(395, 197);
            grpTimKiem.TabIndex = 1;
            grpTimKiem.TabStop = false;
            grpTimKiem.Text = "Tìm kiếm";
            // 
            // chkLocConKinhDoanh
            // 
            chkLocConKinhDoanh.AutoSize = true;
            chkLocConKinhDoanh.Location = new Point(32, 136);
            chkLocConKinhDoanh.Name = "chkLocConKinhDoanh";
            chkLocConKinhDoanh.Size = new Size(226, 24);
            chkLocConKinhDoanh.TabIndex = 2;
            chkLocConKinhDoanh.Text = "Chỉ hiện hàng còn kinh doanh";
            chkLocConKinhDoanh.UseVisualStyleBackColor = true;
            chkLocConKinhDoanh.CheckedChanged += chkLocConKinhDoanh_CheckedChanged;
            // 
            // cboLocLoaiHang
            // 
            cboLocLoaiHang.FormattingEnabled = true;
            cboLocLoaiHang.Location = new Point(26, 86);
            cboLocLoaiHang.Name = "cboLocLoaiHang";
            cboLocLoaiHang.Size = new Size(316, 28);
            cboLocLoaiHang.TabIndex = 1;
            // 
            // txtTimKiem
            // 
            txtTimKiem.Location = new Point(21, 30);
            txtTimKiem.Name = "txtTimKiem";
            txtTimKiem.Size = new Size(321, 27);
            txtTimKiem.TabIndex = 0;
            txtTimKiem.TextChanged += txtTimKiem_TextChanged;
            // 
            // timerSearch
            // 
            timerSearch.Interval = 350;
            timerSearch.Tick += timerSearch_Tick;
            // 
            // dgvHangHoa
            // 
            dgvHangHoa.AllowUserToAddRows = false;
            dgvHangHoa.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvHangHoa.Location = new Point(10, 211);
            dgvHangHoa.Name = "dgvHangHoa";
            dgvHangHoa.ReadOnly = true;
            dgvHangHoa.RowHeadersWidth = 51;
            dgvHangHoa.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvHangHoa.Size = new Size(1119, 239);
            dgvHangHoa.TabIndex = 2;
            dgvHangHoa.CellClick += dgvHangHoa_CellClick;
            // 
            // btnThem
            // 
            btnThem.Location = new Point(34, 464);
            btnThem.Name = "btnThem";
            btnThem.Size = new Size(99, 41);
            btnThem.TabIndex = 3;
            btnThem.Text = "Thêm";
            btnThem.UseVisualStyleBackColor = true;
            btnThem.Click += btnThem_Click;
            // 
            // btnSua
            // 
            btnSua.Location = new Point(176, 465);
            btnSua.Name = "btnSua";
            btnSua.Size = new Size(88, 40);
            btnSua.TabIndex = 4;
            btnSua.Text = "Sửa";
            btnSua.UseVisualStyleBackColor = true;
            btnSua.Click += btnSua_Click;
            // 
            // btnXoa
            // 
            btnXoa.Location = new Point(304, 464);
            btnXoa.Name = "btnXoa";
            btnXoa.Size = new Size(82, 39);
            btnXoa.TabIndex = 5;
            btnXoa.Text = "Xóa";
            btnXoa.UseVisualStyleBackColor = true;
            btnXoa.Click += btnXoa_Click;
            // 
            // btnLamMoi
            // 
            btnLamMoi.Location = new Point(416, 464);
            btnLamMoi.Name = "btnLamMoi";
            btnLamMoi.Size = new Size(98, 39);
            btnLamMoi.TabIndex = 6;
            btnLamMoi.Text = "Làm mới";
            btnLamMoi.UseVisualStyleBackColor = true;
            btnLamMoi.Click += btnLamMoi_Click;
            // 
            // btnXemBangGia
            // 
            btnXemBangGia.Location = new Point(551, 464);
            btnXemBangGia.Name = "btnXemBangGia";
            btnXemBangGia.Size = new Size(116, 38);
            btnXemBangGia.TabIndex = 7;
            btnXemBangGia.Text = "Xem bảng giá";
            btnXemBangGia.UseVisualStyleBackColor = true;
            btnXemBangGia.Click += btnXemBangGia_Click;
            // 
            // btnXuatPdf
            // 
            btnXuatPdf.Location = new Point(700, 464);
            btnXuatPdf.Name = "btnXuatPdf";
            btnXuatPdf.Size = new Size(95, 36);
            btnXuatPdf.TabIndex = 8;
            btnXuatPdf.Text = "Xuất PDF";
            btnXuatPdf.UseVisualStyleBackColor = true;
            btnXuatPdf.Click += btnXuatPdf_Click;
            // 
            // btnXuatExcelLuoi
            // 
            btnXuatExcelLuoi.Location = new Point(824, 464);
            btnXuatExcelLuoi.Name = "btnXuatExcelLuoi";
            btnXuatExcelLuoi.Size = new Size(129, 35);
            btnXuatExcelLuoi.TabIndex = 9;
            btnXuatExcelLuoi.Text = "Xuất Excel \"lưới\"";
            btnXuatExcelLuoi.UseVisualStyleBackColor = true;
            btnXuatExcelLuoi.Click += btnXuatExcelLuoi_Click;
            // 
            // btnXuatExcelTonKho
            // 
            btnXuatExcelTonKho.Location = new Point(980, 461);
            btnXuatExcelTonKho.Name = "btnXuatExcelTonKho";
            btnXuatExcelTonKho.Size = new Size(149, 35);
            btnXuatExcelTonKho.TabIndex = 10;
            btnXuatExcelTonKho.Text = "Xuất Excel tồn kho";
            btnXuatExcelTonKho.UseVisualStyleBackColor = true;
            btnXuatExcelTonKho.Click += btnXuatExcelTonKho_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(12, 525);
            label7.Name = "label7";
            label7.Size = new Size(145, 20);
            label7.TabIndex = 11;
            label7.Text = "Tìm thấy 6 mặt hàng";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1182, 603);
            Controls.Add(label7);
            Controls.Add(btnXuatExcelTonKho);
            Controls.Add(btnXuatExcelLuoi);
            Controls.Add(btnXuatPdf);
            Controls.Add(btnXemBangGia);
            Controls.Add(btnLamMoi);
            Controls.Add(btnXoa);
            Controls.Add(btnSua);
            Controls.Add(btnThem);
            Controls.Add(dgvHangHoa);
            Controls.Add(grpTimKiem);
            Controls.Add(grpThongTin);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            grpThongTin.ResumeLayout(false);
            grpThongTin.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)nudSoLuongTon).EndInit();
            ((System.ComponentModel.ISupportInitialize)nudGiaBan).EndInit();
            grpTimKiem.ResumeLayout(false);
            grpTimKiem.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvHangHoa).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox grpThongTin;
        private Label label1;
        private TextBox txtTenHang;
        private CheckBox chkConKinhDoanh;
        private DateTimePicker dtpNgayNhap;
        private Label label6;
        private NumericUpDown nudSoLuongTon;
        private Label label5;
        private NumericUpDown nudGiaBan;
        private Label label4;
        private ComboBox cboDonVi;
        private Label label3;
        private ComboBox cboLoaiHang;
        private Label label2;
        private GroupBox grpTimKiem;
        private CheckBox chkLocConKinhDoanh;
        private ComboBox cboLocLoaiHang;
        private TextBox txtTimKiem;
        private System.Windows.Forms.Timer timerSearch;
        private DataGridView dgvHangHoa;
        private Button btnThem;
        private Button btnSua;
        private Button btnXoa;
        private Button btnLamMoi;
        private Button btnXemBangGia;
        private Button btnXuatPdf;
        private Button btnXuatExcelLuoi;
        private Button btnXuatExcelTonKho;
        private Label label7;
    }
}
